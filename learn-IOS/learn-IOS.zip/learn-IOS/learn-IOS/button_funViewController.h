//
//  button_funViewController.h
//  learn-IOS
//
//  Created by mrj on 12-12-13.
//  Copyright (c) 2012年 mrj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface button_funViewController : UIViewController{
    
}

@end
