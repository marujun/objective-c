//
//  ViewController.h
//  learn-IOS
//
//  Created by mrj on 12-11-14.
//  Copyright (c) 2012年 mrj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    
}
- (IBAction)operate_addresBook:(id)sender;

- (IBAction)view_Image:(id)sender;

- (IBAction)view_addressBook:(id)sender;

@end
