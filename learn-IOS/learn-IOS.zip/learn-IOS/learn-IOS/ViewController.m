//
//  ViewController.m
//  learn-IOS
//
//  Created by mrj on 12-11-14.
//  Copyright (c) 2012年 mrj. All rights reserved.
//

#import "ViewController.h"
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)operate_addresBook:(id)sender {
    NSLog(@"the button has been click");
    
    NSString *fullPath = [[NSBundle mainBundle] pathForResource:@"Sample" ofType:@"plist"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:fullPath]==NO)
    {
        //没找到则创建一个plist文件
        NSFileManager* fm = [NSFileManager defaultManager];
        [fm createFileAtPath:fullPath contents:nil attributes:nil];
        //创建一个dic，写到plist文件里
        NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:@"mrj",@"name",@"15210943874",@"phone",nil];
        [dic writeToFile:fullPath atomically:YES];
    }
    NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfFile:fullPath];//文件数据类型是*dictionary
    
    NSLog(@"dic is:%@",dictionary);
    
    ABAddressBookRef addressBook = ABAddressBookCreate();
    CFErrorRef error = NULL;
    ABRecordRef contactPerson = ABPersonCreate();//联系人
    //名字
    NSString* nameStr = [dictionary objectForKey:@"name"];
    NSString* phoneNum=[dictionary objectForKey:@"phone"];
    CFStringRef name = CFStringCreateWithCString( kCFAllocatorDefault, [nameStr UTF8String], kCFStringEncodingUTF8);
    ABRecordSetValue(contactPerson, kABPersonFirstNameProperty, name, &error);//写入名字进联系人
    //号码
    ABMultiValueRef phone = ABMultiValueCreateMutable(kABMultiStringPropertyType);
    // ⋯⋯ 添加多个号码
    ABMultiValueAddValueAndLabel(phone, phoneNum, kABPersonPhoneMobileLabel, NULL);//添加移动号码0
    
    ABRecordSetValue(contactPerson, kABPersonPhoneProperty, phone, &error);//写入全部号码进联系人
    
    ABAddressBookAddRecord(addressBook, contactPerson, &error);//写入通讯录
    ABAddressBookSave(addressBook, &error);
    //释放各数据
    CFRelease(name);
    CFRelease(phone);
    CFRelease(contactPerson);
    CFRelease(addressBook);
    
}


- (IBAction)view_Image:(id)sender {
    NSLog(@"start look up image!");
//    在ipad上使用会报错只能在iphone上使用下面的代码调用系统图片库
//    UIImagePickerController* picker =[[UIImagePickerController alloc] init];
//    picker.delegate = self;
//    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//    [self presentModalViewController:picker animated:YES];
    
    
//    在ipad上使用UIPopoverController
    UIImagePickerController* m_imagePicker =[[UIImagePickerController alloc] init];
    m_imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    m_imagePicker.delegate = self;
    [m_imagePicker setAllowsEditing:NO];
    UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:m_imagePicker];
//    popover.delegate = self;
    [popover presentPopoverFromRect:CGRectMake(0, 0, 0, 0) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
//    [popover release];
//    [m_imagePicker release];

}

- (IBAction)view_addressBook:(id)sender {
    ABPeoplePickerNavigationController *picker;
    picker = [[ABPeoplePickerNavigationController alloc] init];        
    // place the delegate of the picker to the controll
    picker.peoplePickerDelegate = self;
    [self presentModalViewController:picker animated:YES];
}
- (void)peoplePickerNavigationController: (ABPeoplePickerNavigationController *)peoplePicker

      shouldContinueAfterSelectingPerson:(ABRecordRef)person{
    NSLog(@"用户选择了通讯录一级列表的某一项");
}
- (void)peoplePickerNavigationControllerDidCancel:(ABPeoplePickerNavigationController *)peoplePicker
{
//    当用户点击cancel按钮时回到主页面
    [peoplePicker dismissModalViewControllerAnimated:YES];
    NSLog(@"回到主页面");
}

@end
